import { Clock, MessageSquare, BarChart3 } from "lucide-react";

export default function FeatureHighlights() {
  const features = [
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Smart Scheduling",
      description: "Automatically fill cancellations and optimize appointment booking to maximize chair time and eliminate scheduling gaps.",
      color: "bg-primary"
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Automated Communications",
      description: "Personalized patient messaging that enhances engagement through timely reminders, follow-ups, and care instructions.",
      color: "bg-teal-500"
    },
    {
      icon: <BarChart3 className="h-6 w-6" />,
      title: "Revenue Analytics",
      description: "Identify untapped revenue opportunities and reactivate overdue treatments through intelligent data analysis.",
      color: "bg-accent"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, idx) => (
            <div 
              key={idx} 
              className="bg-white rounded-xl shadow-sm p-8 transition-transform duration-300 hover:transform hover:scale-105"
            >
              <div className={`flex items-center justify-center h-12 w-12 rounded-md ${feature.color} text-white mb-5`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-sans font-semibold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
