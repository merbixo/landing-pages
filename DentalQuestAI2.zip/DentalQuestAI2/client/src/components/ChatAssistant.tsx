import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Bot, X, MessageSquare, Send, Volume2, VolumeX } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ChatAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{text: string, sender: "user" | "ai", isTyping?: boolean}[]>([]);
  const [input, setInput] = useState("");
  const [isMuted, setIsMuted] = useState(false);
  const [hasPlayedGreeting, setHasPlayedGreeting] = useState(false);
  const [audioError, setAudioError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const assistantName = "Sarah";
  
  // Initial greeting message
  useEffect(() => {
    if (isOpen && !hasPlayedGreeting) {
      // Add initial typing indicator
      setMessages([{ text: "", sender: "ai", isTyping: true }]);
      
      // Play audio greeting when chat is opened for the first time
      if (!isMuted && audioRef.current && !audioError) {
        audioRef.current.play().catch(err => {
          console.error("Audio playback failed:", err);
          setAudioError(true);
        });
      }
      
      // Simulate typing delay then show welcome message
      const typingTimeout = setTimeout(() => {
        setMessages([
          { 
            text: `Hi there! I'm ${assistantName}, your dental AI assistant. How can I help you today? I can provide information about our AI solutions for dental practices.`, 
            sender: "ai" 
          }
        ]);
        setHasPlayedGreeting(true);
      }, 1500);
      
      return () => clearTimeout(typingTimeout);
    }
  }, [isOpen, hasPlayedGreeting, isMuted, audioError]);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (audioRef.current && !audioError) {
      audioRef.current.muted = !isMuted;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    // Add user message
    const userMessage = { text: input, sender: "user" as const };
    setMessages([...messages, userMessage]);
    setInput("");
    
    // Show AI typing indicator
    setTimeout(() => {
      setMessages(prev => [...prev, { text: "", sender: "ai", isTyping: true }]);
      
      // Simulate AI response after delay
      setTimeout(() => {
        // Replace typing indicator with actual response
        setMessages(prev => {
          const newMessages = [...prev];
          // Remove typing indicator
          newMessages.pop();
          // Add actual response
          return [...newMessages, getAIResponse(input)];
        });
      }, 1500);
    }, 500);
  };

  const getAIResponse = (userInput: string): {text: string, sender: "ai"} => {
    const inputLower = userInput.toLowerCase();
    
    // Simple response logic based on keywords
    if (inputLower.includes("appointment") || inputLower.includes("schedule") || inputLower.includes("booking")) {
      return { 
        text: "Our AI scheduling system can help automate your appointment booking and reduce no-shows. Would you like to learn more about this feature?", 
        sender: "ai" 
      };
    } else if (inputLower.includes("price") || inputLower.includes("cost") || inputLower.includes("pricing")) {
      return { 
        text: "Our pricing is customized based on your practice size and needs. Would you like to schedule a demo to discuss pricing options?", 
        sender: "ai" 
      };
    } else if (inputLower.includes("demo") || inputLower.includes("trial")) {
      return { 
        text: "Great! You can request a personalized demo by filling out the form at the bottom of this page. Would you like me to scroll you there?", 
        sender: "ai" 
      };
    } else if (inputLower.includes("leader") || inputLower.includes("full capacity")) {
      return { 
        text: "For practice leaders already at full capacity, our AI solutions help optimize operations, reduce administrative burden, and maximize revenue without adding staff. Would you like specific examples?", 
        sender: "ai" 
      };
    } else if (inputLower.includes("follower") || inputLower.includes("growth")) {
      return { 
        text: "For practices focused on growth, our AI tools help attract new patients, streamline onboarding, and improve patient communication while keeping costs manageable. Would you like to learn more about these features?", 
        sender: "ai" 
      };
    } else {
      return { 
        text: "Thank you for your message. Our AI solutions can help optimize your dental practice operations. Would you like to know more about how we can help leaders or followers in the dental industry?", 
        sender: "ai" 
      };
    }
  };

  return (
    <>
      {/* Audio element for greeting */}
      <audio 
        ref={audioRef} 
        src="/assets/assistant-greeting.mp3" 
        preload="auto"
        onError={() => setAudioError(true)}
      />
      
      {/* Chat toggle button */}
      <Button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg bg-primary hover:bg-primary/90 text-white p-0 flex items-center justify-center z-50"
        aria-label={isOpen ? "Close chat assistant" : "Open chat assistant"}
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </Button>
      
      {/* Chat interface */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-80 sm:w-96 h-[450px] shadow-xl z-50 border-primary/20 overflow-hidden">
          <div className="bg-primary text-white p-3 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center">
              <Avatar className="h-10 w-10 mr-3 border-2 border-white/30">
                <AvatarImage src="/assets/female-assistant.svg" alt={`${assistantName} AI Assistant`} />
                <AvatarFallback className="bg-blue-200">
                  <Bot className="h-5 w-5 text-primary" />
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium text-lg">{assistantName}</h3>
                <p className="text-xs opacity-75">Dental AI Assistant • Online</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMute}
              className={cn(
                "h-8 w-8 text-white hover:bg-white/20",
                audioError && "opacity-50 cursor-not-allowed"
              )}
              disabled={audioError}
              title={audioError ? "Audio unavailable" : isMuted ? "Unmute" : "Mute"}
            >
              {isMuted || audioError ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </Button>
          </div>
          
          <CardContent className="p-4 h-[calc(100%-130px)] overflow-y-auto bg-gradient-to-b from-blue-50 to-white">
            {messages.map((msg, index) => (
              <div 
                key={index} 
                className={`mb-4 flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'ai' && !msg.isTyping && (
                  <Avatar className="h-8 w-8 mr-2 flex-shrink-0 self-end mb-1">
                    <AvatarImage src="/assets/female-assistant.svg" alt={`${assistantName} AI Assistant`} />
                    <AvatarFallback className="bg-blue-200">
                      <Bot className="h-4 w-4 text-primary" />
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div 
                  className={cn(
                    "max-w-[75%] rounded-2xl p-3",
                    msg.sender === 'user' 
                      ? 'bg-primary text-white rounded-tr-none' 
                      : msg.isTyping 
                        ? 'bg-gray-100 text-gray-800 ml-10' 
                        : 'bg-gray-100 text-gray-800 rounded-tl-none'
                  )}
                >
                  {msg.isTyping ? (
                    <div className="flex space-x-1 items-center px-2 py-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  ) : (
                    <p className="text-sm">{msg.text}</p>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </CardContent>
          
          <form onSubmit={handleSubmit} className="p-3 border-t flex bg-white">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 mr-2 bg-gray-100 border-gray-200"
            />
            <Button 
              type="submit" 
              size="icon" 
              disabled={!input.trim()}
              className="bg-primary hover:bg-primary/90"
            >
              <Send size={18} />
            </Button>
          </form>
        </Card>
      )}
    </>
  );
}