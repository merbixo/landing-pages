import { Button } from "@/components/ui/button";
import { Check, CheckCircle } from "lucide-react";
import { scrollToElement } from "@/lib/utils";

export default function LeadersSection() {
  const challenges = [
    "Scheduling inefficiencies",
    "High operational costs",
    "Missed revenue opportunities",
    "Need to elevate patient experience"
  ];

  const messaging = [
    "Eliminate scheduling gaps instantly by automatically filling cancellations, keeping your chairs consistently filled.",
    "Automate personalized patient communications, boosting engagement and retention effortlessly.",
    "Reactivate overdue treatments using insightful analytics, maximizing revenue from your current patient base.",
    "Free your staff from repetitive tasks, enabling them to enhance patient interactions and build stronger loyalty."
  ];

  return (
    <section id="leaders" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-semibold tracking-wide uppercase">For Practice Leaders</span>
          <h2 className="mt-2 text-3xl font-sans font-bold text-gray-900 sm:text-4xl">
            Optimize Your Fully Booked Dental Practice
          </h2>
          <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-600">
            Elevate your fully booked dental practice with smart AI solutions that optimize efficiency, 
            reduce operational costs, and maximize revenue opportunities.
          </p>
        </div>

        <div className="mt-12">
          <div className="lg:flex lg:items-start lg:-mx-4">
            <div className="lg:w-1/2 lg:px-4 mb-8 lg:mb-0">
              <div className="bg-gray-50 rounded-xl shadow-sm p-8 h-full">
                <h3 className="text-2xl font-sans font-semibold text-gray-900 mb-6">Key Challenges Addressed</h3>
                <ul className="space-y-5">
                  {challenges.map((challenge, idx) => (
                    <li key={idx} className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckCircle className="h-6 w-6 text-primary" />
                      </div>
                      <p className="ml-3 text-lg text-gray-700">{challenge}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="lg:w-1/2 lg:px-4">
              <div className="bg-gradient-to-br from-primary to-primary-foreground rounded-xl shadow-md p-8 text-white h-full">
                <h3 className="text-2xl font-sans font-semibold mb-6">Messaging Highlights</h3>
                <ul className="space-y-5">
                  {messaging.map((message, idx) => (
                    <li key={idx} className="flex items-start">
                      <div className="flex-shrink-0">
                        <Check className="h-6 w-6 text-white" />
                      </div>
                      <p className="ml-3 text-lg">{message}</p>
                    </li>
                  ))}
                </ul>
                <div className="mt-10">
                  <Button 
                    onClick={() => scrollToElement("demo")}
                    variant="secondary" 
                    className="w-full sm:w-auto font-medium"
                  >
                    Unlock Your Practice's Full Potential—Schedule Your Personalized AI Demo Today!
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
