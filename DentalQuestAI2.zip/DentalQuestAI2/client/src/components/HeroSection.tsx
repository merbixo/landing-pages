import { Button } from "@/components/ui/button";
import { scrollToElement } from "@/lib/utils";

export default function HeroSection() {
  return (
    <section id="home" className="pt-24 md:pt-32 bg-gradient-to-br from-white to-primary/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="lg:flex items-center justify-between">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="text-4xl md:text-5xl font-sans font-bold text-gray-900 leading-tight">
              AI-Powered Solutions for Modern Dental Practices
            </h1>
            <p className="mt-6 text-lg md:text-xl text-gray-600 leading-relaxed">
              Transform your dental practice with intelligent automation that enhances patient experience, 
              maximizes efficiency, and drives growth.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row">
              <Button 
                onClick={() => scrollToElement("demo")}
                className="bg-accent hover:bg-accent/90 text-white px-6 py-6 h-auto"
              >
                Get Started
              </Button>
              <Button 
                onClick={() => scrollToElement("leaders")}
                variant="outline"
                className="mt-3 sm:mt-0 sm:ml-3 px-6 py-6 h-auto"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="lg:w-5/12">
            <div className="bg-white rounded-xl shadow-xl overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Modern dental practice with digital technology" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Curved divider */}
      <div className="w-full">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" className="fill-current text-white">
          <path d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,100L1360,100C1280,100,1120,100,960,100C800,100,640,100,480,100C320,100,160,100,80,100L0,100Z"></path>
        </svg>
      </div>
    </section>
  );
}
