import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      quote: "The AI scheduling system has completely eliminated our no-show problem. We've seen a 35% increase in revenue just from automatically filling cancelled appointments.",
      author: "Dr. Sarah Johnson",
      position: "Smile Bright Dental, Melbourne",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    },
    {
      quote: "As a new practice, the virtual receptionist has been a game-changer. We're able to capture after-hours calls and book patients 24/7, all without hiring additional staff.",
      author: "Dr. Michael Lee",
      position: "Modern Family Dental, Sydney",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    },
    {
      quote: "The automated recall system has helped us reactivate hundreds of overdue patients. Our hygiene department is now fully booked three months in advance.",
      author: "Dr. Rebecca Wilson",
      position: "Precision Dental Care, Brisbane",
      image: "https://images.unsplash.com/photo-1553867745-6e038d085e86?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-semibold tracking-wide uppercase">Testimonials</span>
          <h2 className="mt-2 text-3xl font-sans font-bold text-gray-900 sm:text-4xl">
            What Our Clients Say
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, idx) => (
            <Card key={idx} className="bg-white rounded-xl shadow-sm">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="text-accent">
                    {/* Stars */}
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <blockquote className="text-gray-700 mb-6">
                  "{testimonial.quote}"
                </blockquote>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-300 flex-shrink-0 overflow-hidden">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.author} 
                      className="h-full w-full object-cover" 
                    />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{testimonial.author}</p>
                    <p className="text-sm text-gray-500">{testimonial.position}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
