import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import LeadersSection from "@/components/LeadersSection";
import FeatureHighlights from "@/components/FeatureHighlights";
import FollowersSection from "@/components/FollowersSection";
import Testimonials from "@/components/Testimonials";
import DemoForm from "@/components/DemoForm";
import Footer from "@/components/Footer";
import ChatAssistant from "@/components/ChatAssistant";

export default function Home() {
  return (
    <div className="font-body text-gray-800 bg-gray-50">
      <Navbar />
      <HeroSection />
      <LeadersSection />
      <FeatureHighlights />
      <FollowersSection />
      <Testimonials />
      <DemoForm />
      <Footer />
      <ChatAssistant />
    </div>
  );
}
