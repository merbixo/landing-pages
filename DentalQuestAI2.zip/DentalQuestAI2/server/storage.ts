import { users, type User, type InsertUser, demoRequests, type DemoRequest, type InsertDemoRequest } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createDemoRequest(request: InsertDemoRequest): Promise<DemoRequest>;
  getAllDemoRequests(): Promise<DemoRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private demoRequests: Map<number, DemoRequest>;
  private userCurrentId: number;
  private demoRequestCurrentId: number;

  constructor() {
    this.users = new Map();
    this.demoRequests = new Map();
    this.userCurrentId = 1;
    this.demoRequestCurrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createDemoRequest(request: InsertDemoRequest): Promise<DemoRequest> {
    const id = this.demoRequestCurrentId++;
    const submittedAt = new Date();
    
    // Create the DemoRequest object explicitly without using spread for type safety
    const demoRequest: DemoRequest = {
      id,
      firstName: request.firstName,
      lastName: request.lastName,
      email: request.email,
      phone: request.phone,
      practiceName: request.practiceName,
      practiceSize: request.practiceSize,
      message: request.message ?? null, // Ensure message is never undefined
      termsAccepted: request.termsAccepted,
      submittedAt
    };
    
    this.demoRequests.set(id, demoRequest);
    return demoRequest;
  }

  async getAllDemoRequests(): Promise<DemoRequest[]> {
    return Array.from(this.demoRequests.values());
  }
}

export const storage = new MemStorage();
