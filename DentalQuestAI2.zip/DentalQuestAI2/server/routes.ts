import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDemoRequestSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Demo request submission route
  app.post("/api/demo-requests", async (req: Request, res: Response) => {
    try {
      const result = insertDemoRequestSchema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationError.details 
        });
      }

      const demoRequest = await storage.createDemoRequest(result.data);
      return res.status(201).json(demoRequest);
    } catch (error) {
      console.error("Error handling demo request:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all demo requests (admin route)
  app.get("/api/demo-requests", async (_req: Request, res: Response) => {
    try {
      const requests = await storage.getAllDemoRequests();
      return res.status(200).json(requests);
    } catch (error) {
      console.error("Error fetching demo requests:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
