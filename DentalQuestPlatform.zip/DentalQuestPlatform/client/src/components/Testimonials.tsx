import React from "react";
import { Star } from "lucide-react";

const testimonials = [
  {
    content: "DentalQuest AI has completely transformed my practice. I've dramatically reduced no-shows and saved countless hours on administrative tasks.",
    author: "Dr. Rebecca Martin",
    practice: "Downtown Dental Care",
    initials: "RM",
  },
  {
    content: "The virtual receptionist handles calls better than I could have imagined. My patients love the quick responses and 24/7 availability.",
    author: "Dr. James Wilson",
    practice: "Smile Design Dentistry",
    initials: "JW",
  },
  {
    content: "The ROI was immediate. Within the first month, I saw increased productivity and happier patients. Best investment I've made for my practice.",
    author: "Dr. Karen Chen",
    practice: "Bayview Dental Associates",
    initials: "KC",
  },
];

const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4 font-heading">
            What Dentists Are Saying
          </h2>
          <p className="text-lg text-neutral-700">
            Hear from dentists who have transformed their operations with DentalQuest AI.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="text-primary flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="fill-current h-4 w-4" />
                  ))}
                </div>
              </div>
              <p className="text-neutral-900 mb-4">"{testimonial.content}"</p>
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-[#4FB3BE] flex items-center justify-center text-white font-semibold">
                    {testimonial.initials}
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-neutral-900">{testimonial.author}</p>
                  <p className="text-xs text-neutral-700">{testimonial.practice}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
