import React from "react";

const stats = [
  { value: "Significant", label: "Reduction in No-Shows" },
  { value: "40+", label: "Hours Saved Per Month" },
  { value: "24/7", label: "Patient Support" },
  { value: "Exceptional", label: "Patient Satisfaction" },
];

const Stats: React.FC = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary">{stat.value}</p>
              <p className="text-neutral-700 mt-2">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
