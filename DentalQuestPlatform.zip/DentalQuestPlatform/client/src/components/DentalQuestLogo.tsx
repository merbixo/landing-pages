import React from "react";

const DentalQuestLogo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="silhouette">
        {/* Head silhouette */}
        <path
          d="M 80,30 C 60,30 45,50 45,80 C 45,110 60,130 80,145 L 80,40 Z"
          fill="#00363a"
        />
        {/* Doctor body shape */}
        <path
          d="M 80,145 L 100,160 L 120,145 L 140,155 L 130,170 L 80,170 L 70,155 Z"
          fill="#00363a"
        />
      </g>
      
      {/* Neural network in brain */}
      <g className="brain-network" stroke="#4FB3BE" strokeWidth="2" fill="none">
        <circle cx="60" cy="60" r="4" fill="#4FB3BE" />
        <circle cx="75" cy="45" r="4" fill="#4FB3BE" />
        <circle cx="65" cy="80" r="4" fill="#4FB3BE" />
        <circle cx="55" cy="95" r="4" fill="#4FB3BE" />
        <circle cx="70" cy="110" r="4" fill="#4FB3BE" />
        <circle cx="60" cy="125" r="4" fill="#4FB3BE" />
        <line x1="60" y1="60" x2="75" y2="45" />
        <line x1="60" y1="60" x2="65" y2="80" />
        <line x1="65" y1="80" x2="55" y2="95" />
        <line x1="55" y1="95" x2="70" y2="110" />
        <line x1="70" y1="110" x2="60" y2="125" />
      </g>
      
      {/* Stethoscope */}
      <g className="stethoscope" stroke="#00838F" strokeWidth="3" fill="none">
        <circle cx="90" cy="145" r="6" />
        <path d="M 90,145 C 85,130 75,135 70,145" />
      </g>
      
      {/* Digital particles */}
      <g className="particles" fill="#4FB3BE">
        <circle cx="90" cy="40" r="2" />
        <circle cx="95" cy="50" r="2" />
        <circle cx="85" cy="45" r="2" />
        <circle cx="92" cy="35" r="2" />
        <circle cx="88" cy="55" r="2" />
      </g>
      
      {/* Lab coat */}
      <path
        d="M 95,145 L 105,145 L 110,165 L 90,165 Z"
        fill="#ffffff"
        stroke="#e0e0e0"
        strokeWidth="1"
      />
    </svg>
  );
};

export default DentalQuestLogo;
