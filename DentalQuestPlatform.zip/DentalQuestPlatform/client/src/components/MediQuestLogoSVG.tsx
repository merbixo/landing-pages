import React from "react";

interface LogoProps {
  className?: string;
  width?: number | string;
  height?: number | string;
}

const MediQuestLogoSVG: React.FC<LogoProps> = ({ className, width = "100%", height = "auto" }) => {
  return (
    <svg 
      width={width} 
      height={height} 
      viewBox="0 0 400 150" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Brain and Doctor Silhouette */}
      <path d="M180 40 A40 40 0 0 1 140 80 L140 110 L180 110" fill="#0B2B36" />
      
      {/* Neural Network */}
      <circle cx="150" cy="50" r="4" fill="#4FB3BE" />
      <circle cx="160" cy="45" r="4" fill="#4FB3BE" />
      <circle cx="170" cy="50" r="4" fill="#4FB3BE" />
      <circle cx="165" cy="60" r="4" fill="#4FB3BE" />
      <circle cx="155" cy="65" r="4" fill="#4FB3BE" />
      <circle cx="160" cy="75" r="4" fill="#4FB3BE" />
      <line x1="150" y1="50" x2="160" y2="45" stroke="white" strokeWidth="1.5" />
      <line x1="160" y1="45" x2="170" y2="50" stroke="white" strokeWidth="1.5" />
      <line x1="170" y1="50" x2="165" y2="60" stroke="white" strokeWidth="1.5" />
      <line x1="165" y1="60" x2="155" y2="65" stroke="white" strokeWidth="1.5" />
      <line x1="155" y1="65" x2="160" y2="75" stroke="white" strokeWidth="1.5" />
      <line x1="160" y1="45" x2="165" y2="60" stroke="white" strokeWidth="1.5" />
      <line x1="150" y1="50" x2="155" y2="65" stroke="white" strokeWidth="1.5" />
      
      {/* Stethoscope */}
      <path d="M145 100 Q140 115 150 120 T160 110" stroke="#0B2B36" strokeWidth="3" fill="none" />
      <circle cx="160" cy="110" r="5" fill="#4FB3BE" stroke="#0B2B36" strokeWidth="1" />
      
      {/* Suit outline */}
      <path d="M155 90 L145 110 L160 100 L175 110 L165 90" stroke="#0B2B36" strokeWidth="2" fill="none" />
      <path d="M145 95 L155 105" stroke="#4FB3BE" strokeWidth="2" />
      
      {/* Logo Text */}
      <text x="190" y="90" fontFamily="Arial" fontWeight="bold" fontSize="32" fill="#0B2B36">Medi<tspan fill="#4FB3BE">Quest</tspan><tspan fontSize="18">.AI</tspan></text>
      
      {/* Tagline */}
      <text x="190" y="110" fontFamily="Arial" fontWeight="bold" fontSize="12" fill="#0B2B36">SOLO DOCTOR PRACTICE</text>
      <text x="190" y="125" fontFamily="Arial" fontWeight="bold" fontSize="12" fill="#4FB3BE">SMART INSIGHTS</text>
      
      {/* Particles */}
      <circle cx="185" cy="55" r="2" fill="#4FB3BE" />
      <circle cx="190" cy="50" r="2" fill="#4FB3BE" />
      <circle cx="195" cy="45" r="2" fill="#4FB3BE" />
      <circle cx="195" cy="55" r="3" fill="#4FB3BE" />
      <circle cx="200" cy="50" r="2" fill="#4FB3BE" />
    </svg>
  );
};

export default MediQuestLogoSVG;