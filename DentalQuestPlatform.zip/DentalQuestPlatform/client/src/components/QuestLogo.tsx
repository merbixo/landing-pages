import React from "react";
import logoPath from "@assets/image_1743039633205.png";
import MediQuestLogoSVG from "./MediQuestLogoSVG";
import DentalQuestLogoSVG from "./DentalQuestLogoSVG";

interface LogoProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  variant?: "mediquestImage" | "mediquest" | "dentalquest";
}

const QuestLogo: React.FC<LogoProps> = ({ 
  className, 
  width = 200, 
  height = "auto", 
  variant = "dentalquest" 
}) => {
  if (variant === "mediquest") {
    return <MediQuestLogoSVG className={className} width={width} height={height} />;
  } else if (variant === "mediquestImage") {
    return (
      <img 
        src={logoPath} 
        alt="DentalQuest.AI Logo" 
        className={className}
        style={{ width, height }}
      />
    );
  } else {
    return <DentalQuestLogoSVG className={className} width={width} height={height} />;
  }
};

export default QuestLogo;