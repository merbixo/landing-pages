import React from "react";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const features = [
  "2 AI Staff Members",
  "AI Dental Receptionist + Scheduler combination",
  "Custom Configuration for your dental practice",
  "Seamless Integration with Dental Software Systems",
  "Dedicated Support During Setup",
  "Monthly Performance Analytics",
];

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4 font-heading">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-neutral-700">
            Get started with our AI team members at a fraction of the cost of traditional staff.
          </p>
        </div>
        
        <div className="flex justify-center">
          <div className="max-w-md w-full">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="bg-primary px-6 py-8 text-center">
                <h3 className="text-xl font-bold text-white mb-2 font-heading">
                  AI Team Starter
                </h3>
                <div className="flex items-center justify-center">
                  <span className="text-4xl font-bold text-white">$1,990</span>
                  <span className="text-white ml-2">/month</span>
                </div>
              </div>
              <div className="p-6">
                <ul className="space-y-4">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="text-primary mt-1 mr-3 h-5 w-5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-8">
                  <Button className="w-full" size="lg" asChild>
                    <a href="#get-started">Get Started</a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-neutral-700">
            Need a custom solution? Call us for personalized pricing options tailored to your dental practice.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
