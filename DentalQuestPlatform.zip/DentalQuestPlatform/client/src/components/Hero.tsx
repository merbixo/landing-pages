import React from "react";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

const Hero: React.FC = () => {
  return (
    <section className="relative bg-[#B3E5FC] overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6 font-heading">
              AI-Powered Solutions for Dental Practices
            </h1>
            <p className="text-lg mb-8 text-neutral-700 max-w-lg">
              Streamline your dental practice with intelligent AI staff that handle scheduling, 
              patient communication, and administrative tasks.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button size="lg" asChild>
                <a href="#pricing">
                  Get Started
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-2 h-4 w-4"
                  >
                    <line x1="5" y1="12" x2="19" y2="12" />
                    <polyline points="12 5 19 12 12 19" />
                  </svg>
                </a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="#demo" className="text-primary">
                  <Play className="mr-2 h-4 w-4" /> Watch Demo
                </a>
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="relative h-64 sm:h-72 md:h-80 lg:h-96 rounded-lg overflow-hidden shadow-2xl bg-gradient-to-r from-blue-50 to-blue-100">
              <div className="w-full h-full flex items-center justify-center">
                {/* Dentist and AI Assistant SVG illustration */}
                <svg
                  width="100%"
                  height="100%"
                  viewBox="0 0 500 400"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="p-4"
                >
                  {/* Background elements */}
                  <circle cx="250" cy="150" r="100" fill="#E3F2FD" opacity="0.8" />
                  <circle cx="150" cy="250" r="80" fill="#BBDEFB" opacity="0.5" />
                  <circle cx="350" cy="250" r="80" fill="#BBDEFB" opacity="0.5" />
                  
                  {/* Dentist illustration */}
                  <g transform="translate(280, 120) scale(0.9)">
                    {/* Dentist head */}
                    <ellipse cx="70" cy="60" rx="35" ry="40" fill="#F5CBA7" />
                    <path d="M45 45 Q70 80 95 45" stroke="#333" strokeWidth="2" fill="none" />
                    <circle cx="55" cy="50" r="3" fill="#333" />
                    <circle cx="85" cy="50" r="3" fill="#333" />
                    
                    {/* Hair */}
                    <path d="M35 35 Q70 10 105 35 L105 60 Q70 75 35 60 Z" fill="#4A4A4A" />
                    
                    {/* Body/lab coat */}
                    <path d="M40 100 L40 220 Q70 240 100 220 L100 100 Z" fill="white" stroke="#DDDDDD" strokeWidth="1" />
                    <path d="M40 100 Q70 115 100 100" stroke="#DDDDDD" strokeWidth="1" fill="none" />
                    
                    {/* Arms */}
                    <path d="M40 120 L15 180" stroke="#F5CBA7" strokeWidth="12" strokeLinecap="round" />
                    <path d="M100 120 L125 180" stroke="#F5CBA7" strokeWidth="12" strokeLinecap="round" />
                    
                    {/* Stethoscope */}
                    <path d="M60 140 Q65 160 75 165 Q85 170 85 180 L90 190" stroke="#0066CC" strokeWidth="3" fill="none" />
                    <circle cx="90" cy="195" r="5" fill="#0066CC" />
                    
                    {/* Dental tool */}
                    <line x1="125" y1="180" x2="150" y2="170" stroke="#DDDDDD" strokeWidth="2" />
                    <path d="M150 170 L160 165 L158 178 Z" fill="#00B8D4" />
                  </g>
                  
                  {/* AI Assistant illustration */}
                  <g transform="translate(120, 100) scale(0.8)">
                    {/* Robot head */}
                    <rect x="40" y="40" width="80" height="70" rx="10" fill="#0066CC" />
                    <rect x="50" y="55" width="60" height="40" rx="5" fill="#B3E5FC" />
                    
                    {/* Robot antenna */}
                    <line x1="80" y1="40" x2="80" y2="25" stroke="#0066CC" strokeWidth="3" />
                    <circle cx="80" cy="20" r="5" fill="#00B8D4" />
                    
                    {/* Robot eyes */}
                    <circle cx="65" cy="75" r="10" fill="#004080" />
                    <circle cx="65" cy="75" r="5" fill="#00B8D4" />
                    <circle cx="95" cy="75" r="10" fill="#004080" />
                    <circle cx="95" cy="75" r="5" fill="#00B8D4" />
                    
                    {/* Robot body */}
                    <rect x="50" y="110" width="60" height="80" rx="5" fill="#0066CC" />
                    <rect x="60" y="120" width="40" height="60" rx="3" fill="#B3E5FC" />
                    
                    {/* Robot arms */}
                    <line x1="50" y1="120" x2="20" y2="140" stroke="#0066CC" strokeWidth="8" strokeLinecap="round" />
                    <line x1="110" y1="120" x2="140" y2="140" stroke="#0066CC" strokeWidth="8" strokeLinecap="round" />
                    
                    {/* Robot hands */}
                    <circle cx="20" cy="140" r="8" fill="#B3E5FC" stroke="#0066CC" strokeWidth="2" />
                    <circle cx="140" cy="140" r="8" fill="#B3E5FC" stroke="#0066CC" strokeWidth="2" />
                    
                    {/* Digital display elements */}
                    <line x1="65" y1="130" x2="95" y2="130" stroke="#00B8D4" strokeWidth="2" />
                    <line x1="65" y1="140" x2="85" y2="140" stroke="#00B8D4" strokeWidth="2" />
                    <line x1="65" y1="150" x2="95" y2="150" stroke="#00B8D4" strokeWidth="2" />
                    <line x1="75" y1="160" x2="95" y2="160" stroke="#00B8D4" strokeWidth="2" />
                    
                    {/* Connection visual between AI and Dentist */}
                    <path d="M140 140 Q165 150 170 140" stroke="#00B8D4" strokeWidth="2" strokeDasharray="4 2" />
                  </g>
                  
                  {/* Neural network connections between AI and Dentist */}
                  <g opacity="0.7">
                    <line x1="200" y1="140" x2="280" y2="140" stroke="#00B8D4" strokeWidth="1.5" strokeDasharray="5 3" />
                    <line x1="200" y1="170" x2="280" y2="170" stroke="#00B8D4" strokeWidth="1.5" strokeDasharray="5 3" />
                    <line x1="200" y1="200" x2="280" y2="200" stroke="#00B8D4" strokeWidth="1.5" strokeDasharray="5 3" />
                    
                    <circle cx="240" cy="140" r="3" fill="#00B8D4" />
                    <circle cx="250" cy="170" r="3" fill="#00B8D4" />
                    <circle cx="230" cy="200" r="3" fill="#00B8D4" />
                  </g>
                  
                  {/* Digital elements floating */}
                  <g opacity="0.8">
                    <rect x="220" y="100" width="20" height="15" rx="2" fill="#00B8D4" opacity="0.4" />
                    <rect x="250" y="120" width="25" height="12" rx="2" fill="#00B8D4" opacity="0.3" />
                    <rect x="230" y="230" width="15" height="20" rx="2" fill="#00B8D4" opacity="0.2" />
                    <circle cx="270" cy="230" r="8" fill="#00B8D4" opacity="0.2" />
                    <circle cx="210" cy="190" r="5" fill="#00B8D4" opacity="0.3" />
                  </g>
                </svg>
              </div>
            </div>
            
            {/* AI Assistant card */}
            <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-[#0066CC] flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M12 2a9 9 0 0 1 9 9c0 3.86-3.13 7-7 7h-4" />
                      <path d="M12 2a9 9 0 0 0-9 9c0 3.86 3.13 7 7 7h4" />
                      <path d="M9 16V8h4" />
                      <path d="M15 16V8" />
                    </svg>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-900">AI-Powered</p>
                  <p className="text-xs text-neutral-700">Dental Practice Assistant</p>
                </div>
              </div>
            </div>
            
            {/* Dental tools card */}
            <div className="absolute -top-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-[#00B8D4] flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M4.12 4.12 A5 5 0 0 0 5 10 A5 5 0 0 0 10 5 A5 5 0 0 0 4.12 4.12" />
                      <path d="M10 10 L16 16" />
                      <path d="M15 15 L20 20" />
                    </svg>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-900">Smart Scheduling</p>
                  <p className="text-xs text-neutral-700">Optimize Patient Flow</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 -mt-20 -mr-20 hidden lg:block">
        <div className="h-64 w-64 rounded-full bg-[#0066CC] opacity-10"></div>
      </div>
      <div className="absolute bottom-0 left-0 -mb-16 -ml-16 hidden lg:block">
        <div className="h-40 w-40 rounded-full bg-primary opacity-10"></div>
      </div>
    </section>
  );
};

export default Hero;
