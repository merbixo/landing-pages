import React from "react";

const steps = [
  {
    number: 1,
    title: "Configure Your AI Team",
    description: "Select and customize your AI staff members based on your practice's specific needs.",
  },
  {
    number: 2,
    title: "Integrate with Your Systems",
    description: "Quick and seamless integration with your existing practice management software.",
  },
  {
    number: 3,
    title: "Watch Your Practice Transform",
    description: "Experience immediate efficiency gains as your AI team handles routine tasks.",
  },
];

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4 font-heading">
            How DentalQuest.AI Works
          </h2>
          <p className="text-lg text-neutral-700">
            Implementing our AI solution is simple, with minimal disruption to your solo dental practice.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-primary text-white text-2xl font-bold flex items-center justify-center mb-6">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mb-3 font-heading">{step.title}</h3>
              <p className="text-neutral-700">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
