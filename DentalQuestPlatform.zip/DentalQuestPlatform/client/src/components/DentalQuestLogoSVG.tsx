import React from "react";

interface LogoProps {
  className?: string;
  width?: number | string;
  height?: number | string;
}

const DentalQuestLogoSVG: React.FC<LogoProps> = ({ className, width = "100%", height = "auto" }) => {
  return (
    <svg 
      width={width} 
      height={height} 
      viewBox="0 0 500 180" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background gradient effect */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0057B8" stopOpacity="0.1" />
          <stop offset="100%" stopColor="#00B8D4" stopOpacity="0.1" />
        </linearGradient>
        <radialGradient id="glowEffect" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
          <stop offset="0%" stopColor="#00B8D4" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#0057B8" stopOpacity="0" />
        </radialGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <clipPath id="roundMask">
          <circle cx="150" cy="85" r="55" />
        </clipPath>
      </defs>
      
      {/* Backdrop glow */}
      <circle cx="150" cy="85" r="65" fill="url(#glowEffect)" opacity="0.6" />
      
      {/* Main background circle */}
      <circle cx="150" cy="85" r="55" fill="url(#logoGradient)" />
      
      {/* AI Brain visualization (more detailed with depth) */}
      <g filter="url(#glow)">
        {/* Brain structure */}
        <path d="M150 40 
                C170 40, 190 45, 190 60 
                C190 75, 180 80, 185 90 
                C190 100, 185 110, 175 115
                C165 120, 160 130, 150 130
                C140 130, 135 120, 125 115
                C115 110, 110 100, 115 90
                C120 80, 110 75, 110 60
                C110 45, 130 40, 150 40Z" 
              fill="#0066CC" opacity="0.6" />
        
        {/* Neural network nodes - larger more prominent with glow */}
        <circle cx="135" cy="55" r="5" fill="#00B8D4" />
        <circle cx="165" cy="55" r="5" fill="#00B8D4" />
        <circle cx="150" cy="50" r="5" fill="#00B8D4" />
        <circle cx="125" cy="70" r="5" fill="#00B8D4" />
        <circle cx="175" cy="70" r="5" fill="#00B8D4" />
        <circle cx="140" cy="85" r="5" fill="#00B8D4" />
        <circle cx="160" cy="85" r="5" fill="#00B8D4" />
        <circle cx="150" cy="100" r="5" fill="#00B8D4" />
        <circle cx="130" cy="100" r="5" fill="#00B8D4" />
        <circle cx="170" cy="100" r="5" fill="#00B8D4" />
        <circle cx="140" cy="115" r="5" fill="#00B8D4" />
        <circle cx="160" cy="115" r="5" fill="#00B8D4" />

        {/* Neural connections - pulsating effect with bright connectors */}
        <line x1="135" y1="55" x2="150" y2="50" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="150" y1="50" x2="165" y2="55" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="135" y1="55" x2="125" y2="70" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="165" y1="55" x2="175" y2="70" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="125" y1="70" x2="140" y2="85" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="175" y1="70" x2="160" y2="85" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="140" y1="85" x2="130" y2="100" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="160" y1="85" x2="170" y2="100" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="140" y1="85" x2="150" y2="100" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="160" y1="85" x2="150" y2="100" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="130" y1="100" x2="140" y2="115" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="170" y1="100" x2="160" y2="115" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="150" y1="100" x2="140" y2="115" stroke="#00B8D4" strokeWidth="1.5" />
        <line x1="150" y1="100" x2="160" y2="115" stroke="#00B8D4" strokeWidth="1.5" />
      </g>
      
      {/* Integrated tooth icon (more sculptural) */}
      <path d="M150 85 
               q-12 0 -15 10 
               q-3 10 0 15 
               q3 5 7 7 
               q4 2 8 0 
               q4 -2 7 -7 
               q3 -5 0 -15 
               q-3 -10 -15 -10" 
            fill="#FFFFFF" stroke="#0066CC" strokeWidth="1.5" />
      <path d="M143 95 
               q2 2 7 2 
               q5 0 7 -2" 
            fill="none" stroke="#0066CC" strokeWidth="1" />
      
      {/* Floating particles with animated-like positioning */}
      <g opacity="0.8">
        <circle cx="120" cy="45" r="2" fill="#00B8D4" />
        <circle cx="190" cy="65" r="3" fill="#00B8D4" />
        <circle cx="105" cy="90" r="2" fill="#00B8D4" />
        <circle cx="190" cy="110" r="2.5" fill="#00B8D4" />
        <circle cx="130" cy="130" r="1.5" fill="#00B8D4" />
        <circle cx="170" cy="130" r="1" fill="#00B8D4" />
        <circle cx="110" cy="50" r="1" fill="#00B8D4" />
        <circle cx="180" cy="50" r="1.5" fill="#00B8D4" />
      </g>
      
      {/* Logo Text - Bold, modern styling with dynamic spacing */}
      <text x="230" y="90" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="42" letterSpacing="0" fill="#004080">
        Dental<tspan fill="#00B8D4" fontWeight="900">Quest</tspan>
      </text>
      <text x="430" y="90" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="24" fill="#00B8D4">.AI</text>
      
      {/* Modern tagline with stronger emphasis */}
      <text x="230" y="118" fontFamily="Arial, sans-serif" fontWeight="bold" fontSize="14" fill="#004080" letterSpacing="1">
        ADVANCED DENTAL AI
      </text>
      <text x="230" y="140" fontFamily="Arial, sans-serif" fontWeight="bold" fontSize="14" fill="#00B8D4" letterSpacing="1">
        TRANSFORMING PRACTICES
      </text>
    </svg>
  );
};

export default DentalQuestLogoSVG;