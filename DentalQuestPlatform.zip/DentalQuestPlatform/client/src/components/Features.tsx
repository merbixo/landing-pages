import React from "react";
import { 
  CalendarCheck2, 
  MessageSquare, 
  ClipboardList, 
  FileText, 
  HelpingHand, 
  ListChecks 
} from "lucide-react";

const features = [
  {
    icon: <CalendarCheck2 className="text-white w-6 h-6" />,
    title: "Intelligent Scheduling",
    description: "AI-optimized appointment scheduling that reduces gaps and maximizes productivity.",
    color: "#0066CC",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 4h-2V3a1 1 0 0 0-2 0v1H9V3a1 1 0 0 0-2 0v1H5a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-9h16v9zm0-11H4V7a1 1 0 0 1 1-1h2v1a1 1 0 0 0 2 0V6h6v1a1 1 0 0 0 2 0V6h2a1 1 0 0 1 1 1v1z"/>
        <path d="M15 16h-2v-2a1 1 0 0 0-2 0v2H9a1 1 0 0 0 0 2h2v2a1 1 0 0 0 2 0v-2h2a1 1 0 0 0 0-2z"/>
      </svg>
    )
  },
  {
    icon: <MessageSquare className="text-white w-6 h-6" />,
    title: "Patient Communication",
    description: "Automated reminders, confirmations, and follow-ups to keep patients engaged and informed.",
    color: "#2196F3",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.2L4 17.2V4h16v12z"/>
        <path d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/>
      </svg>
    )
  },
  {
    icon: <ClipboardList className="text-white w-6 h-6" />,
    title: "Practice Analytics",
    description: "Real-time insights into practice performance, patient trends, and revenue opportunities.",
    color: "#00B8D4",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20 3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H4V5h16v14z"/>
        <path d="M7 10h10v2H7zm0 4h7v2H7zm0-8h4v2H7z"/>
        <path d="M16 16.5l-1.5-1.5 1.5-1.5V16.5z"/>
      </svg>
    )
  },
  {
    icon: <FileText className="text-white w-6 h-6" />,
    title: "Insurance Verification",
    description: "Automated insurance eligibility checks to prevent claim denials and payment delays.",
    color: "#4CAF50",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/>
        <path d="M10 14.2l-2.6-2.6L6 13l4 4 8-8-1.4-1.4z"/>
      </svg>
    )
  },
  {
    icon: <HelpingHand className="text-white w-6 h-6" />,
    title: "Virtual Assistant",
    description: "AI-powered receptionist handling calls, messages, and routine patient inquiries.",
    color: "#304FFE",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/>
      </svg>
    )
  },
  {
    icon: <ListChecks className="text-white w-6 h-6" />,
    title: "Workflow Automation",
    description: "Streamlined operations with automated task management and staff coordination.",
    color: "#673AB7",
    illustration: (
      <svg className="absolute right-4 bottom-4 w-16 h-16 opacity-10" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"/>
        <path d="M18 9l-1.4-1.4-6.6 6.6-2.6-2.6L6 13l4 4z"/>
      </svg>
    )
  },
];

const Features: React.FC = () => {
  return (
    <section id="features" className="py-16 bg-gradient-to-b from-white to-blue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block p-2 px-4 bg-blue-100 rounded-full text-primary text-sm font-medium mb-4">
            Powerful Features
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4 font-heading">
            Advanced AI Solutions for Modern Dental Practices
          </h2>
          <p className="text-lg text-neutral-700">
            Our AI-powered platform automates routine tasks, enabling you to focus on providing exceptional dental care.
          </p>
        </div>
        
        {/* AI Dentist SVG Illustration */}
        <div className="flex justify-center mb-16">
          <svg width="200" height="80" viewBox="0 0 200 80" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M30 20 L50 20 L60 30 L50 40 L30 40 L20 30 Z" fill="#B3E5FC" />
            <path d="M35 25 L45 25 L50 30 L45 35 L35 35 L30 30 Z" fill="white" />
            <path d="M70 20 L90 20 L100 30 L90 40 L70 40 L60 30 Z" fill="#B3E5FC" />
            <path d="M75 25 L85 25 L90 30 L85 35 L75 35 L70 30 Z" fill="white" />
            <path d="M110 20 L130 20 L140 30 L130 40 L110 40 L100 30 Z" fill="#B3E5FC" />
            <path d="M115 25 L125 25 L130 30 L125 35 L115 35 L110 30 Z" fill="white" />
            <path d="M150 20 L170 20 L180 30 L170 40 L150 40 L140 30 Z" fill="#B3E5FC" />
            <path d="M155 25 L165 25 L170 30 L165 35 L155 35 L150 30 Z" fill="white" />
            
            <line x1="40" y1="40" x2="40" y2="60" stroke="#0066CC" strokeWidth="2" />
            <line x1="80" y1="40" x2="80" y2="60" stroke="#0066CC" strokeWidth="2" />
            <line x1="120" y1="40" x2="120" y2="60" stroke="#0066CC" strokeWidth="2" />
            <line x1="160" y1="40" x2="160" y2="60" stroke="#0066CC" strokeWidth="2" />
            
            <line x1="40" y1="60" x2="160" y2="60" stroke="#0066CC" strokeWidth="2" />
            
            <circle cx="40" cy="30" r="3" fill="#0066CC" />
            <circle cx="80" cy="30" r="3" fill="#0066CC" />
            <circle cx="120" cy="30" r="3" fill="#0066CC" />
            <circle cx="160" cy="30" r="3" fill="#0066CC" />
          </svg>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="relative bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden border-t-4"
              style={{ borderTopColor: feature.color }}
            >
              <div className="flex items-start space-x-4">
                <div 
                  className="h-14 w-14 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: feature.color }}
                >
                  {feature.icon}
                </div>
                <div className="flex-grow">
                  <h3 className="text-xl font-bold mb-3 text-neutral-900">{feature.title}</h3>
                  <p className="text-neutral-700">{feature.description}</p>
                </div>
              </div>
              <div className="text-neutral-900" style={{ color: feature.color }}>
                {feature.illustration}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-block bg-white p-4 rounded-xl shadow-md">
            <div className="flex items-center justify-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-[#0066CC]"></div>
              <p className="text-neutral-700 font-medium">AI-Powered Solutions</p>
              <div className="w-3 h-3 rounded-full bg-[#00B8D4]"></div>
              <p className="text-neutral-700 font-medium">Cutting-Edge Technology</p>
              <div className="w-3 h-3 rounded-full bg-[#4CAF50]"></div>
              <p className="text-neutral-700 font-medium">Dental Excellence</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
