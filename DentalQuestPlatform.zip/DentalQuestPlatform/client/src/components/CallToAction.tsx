import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, PhoneCall } from "lucide-react";

const CallToAction: React.FC = () => {
  return (
    <section className="py-16 bg-primary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6 font-heading">
            Ready to Transform Your Dental Practice?
          </h2>
          <p className="text-xl text-white opacity-90 mb-8">
            Join successful dental practices that have streamlined their operations with DentalQuest.AI.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Button variant="secondary" size="lg" asChild>
              <a href="#pricing">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button variant="outline" size="lg" className="text-white border-white hover:bg-primary-dark" asChild>
              <a href="#demo">
                <PhoneCall className="mr-2 h-4 w-4" />
                Schedule a Demo
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
