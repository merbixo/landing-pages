import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="text-2xl font-bold mb-4">
              <span className="text-white">Dental</span><span className="text-[#00d084]">AI</span>
            </div>
            <p className="text-neutral-400 mb-4">
              Intelligent solutions for dental practices, powered by artificial intelligence.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white transition">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition">
                <Instagram size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Solutions</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Scheduling System</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Patient Communications</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Revenue Optimization</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Analytics Dashboard</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-400 hover:text-white transition">About Us</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Our Team</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Careers</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition">Contact Us</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400">© 2023 DentalAI. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-neutral-400 hover:text-white transition">Privacy Policy</a>
            <a href="#" className="text-neutral-400 hover:text-white transition">Terms of Service</a>
            <a href="#" className="text-neutral-400 hover:text-white transition">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
