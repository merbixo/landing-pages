import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { fadeIn, slideInUp } from "@/lib/animations";
import { MessageSquare, Send } from "lucide-react";
import AudioGreeting from "./AudioGreeting";

const GREETING_TEXT = "Hello! I'm Sophie, your virtual dental assistant. How can I help you optimize your dental practice today?";

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      text: GREETING_TEXT,
      isBot: true
    }
  ]);
  const [input, setInput] = useState("");
  const [hasGreeted, setHasGreeted] = useState(false);

  // Auto-open the chat on first load
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!hasGreeted) {
        setIsOpen(true);
        setHasGreeted(true);
      }
    }, 5000);
    
    return () => clearTimeout(timer);
  }, [hasGreeted]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    // Add user message
    setMessages([...messages, { text: input, isBot: false }]);
    setInput("");
    
    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "Our AI solution can help you optimize your scheduling to minimize gaps and no-shows.",
        "We can automate patient communications to free up your staff's time for more important tasks.",
        "Our analytics tools can help identify unscheduled treatment opportunities in your patient base.",
        "Would you like to schedule a personalized demo to see how our AI solution works specifically for your practice?"
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setMessages(prevMessages => [...prevMessages, { text: randomResponse, isBot: true }]);
    }, 1000);
  };

  return (
    <>
      {/* Chat toggle button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 bg-primary text-white p-4 rounded-full shadow-lg z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        aria-label="Chat with AI Assistant"
      >
        <MessageSquare />
      </motion.button>

      {/* Chat widget */}
      {isOpen && (
        <motion.div
          variants={slideInUp}
          initial="hidden"
          animate="visible"
          className="fixed bottom-20 right-6 w-80 sm:w-96 bg-white rounded-lg shadow-xl overflow-hidden z-50 border border-neutral-200"
        >
          {/* Header with female AI assistant persona */}
          <div className="bg-primary text-white p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mr-3 overflow-hidden">
                {/* Professional AI assistant avatar */}
                <img 
                  src="https://api.dicebear.com/7.x/personas/svg?seed=Sophie&backgroundColor=b6e3f4&earrings=variant01&eyebrows=variant09&eyes=variant26&hair=short22&mouth=lipstick&skinColor=f2d3b1"
                  alt="AI Assistant Avatar"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback if image fails to load
                    e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23f0f0f0'/%3E%3C/svg%3E";
                    e.currentTarget.style.background = "#ffffff20";
                    e.currentTarget.style.display = "flex";
                    e.currentTarget.style.alignItems = "center";
                    e.currentTarget.style.justifyContent = "center";
                  }}
                />
              </div>
              <div>
                <h3 className="font-bold">Sophie</h3>
                <p className="text-xs opacity-80">Your Dental AI Assistant</p>
              </div>
            </div>
            <AudioGreeting />
          </div>

          {/* Messages */}
          <div className="h-80 overflow-y-auto p-4 bg-neutral-50">
            {messages.map((message, index) => (
              <motion.div
                key={index}
                variants={fadeIn}
                initial="hidden"
                animate="visible"
                custom={index}
                className={`mb-4 ${message.isBot ? "mr-12" : "ml-12"}`}
              >
                <div 
                  className={`p-3 rounded-lg ${
                    message.isBot 
                      ? "bg-white border border-neutral-200 rounded-tl-none" 
                      : "bg-primary text-white rounded-tr-none"
                  }`}
                >
                  {message.text}
                </div>
                <div className={`text-xs mt-1 text-neutral-500 ${message.isBot ? "text-left" : "text-right"}`}>
                  {message.isBot ? "Dental AI" : "You"}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Input */}
          <form onSubmit={handleSendMessage} className="border-t border-neutral-200 p-3 flex">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 p-2 border border-neutral-300 rounded-l-md focus:outline-none focus:border-primary"
            />
            <button 
              type="submit"
              className="bg-primary text-white p-2 rounded-r-md"
              disabled={!input.trim()}
              aria-label="Send message"
            >
              <Send size={18} />
            </button>
          </form>
        </motion.div>
      )}
    </>
  );
}