import { motion } from "framer-motion";
import { fadeIn, staggerContainer } from "@/lib/animations";
import { 
  Calendar, 
  DollarSign, 
  BarChart2, 
  Users
} from "lucide-react";

const challenges = [
  {
    icon: <Calendar className="text-primary text-2xl" />,
    title: "Scheduling Inefficiencies",
    description: "Eliminate scheduling gaps by automatically filling cancellations, keeping your chairs consistently filled."
  },
  {
    icon: <DollarSign className="text-primary text-2xl" />,
    title: "High Operational Costs",
    description: "Streamline operations and reduce administrative overhead with intelligent automation solutions."
  },
  {
    icon: <BarChart2 className="text-primary text-2xl" />,
    title: "Missed Revenue Opportunities",
    description: "Identify and capitalize on untapped revenue streams within your existing patient base."
  },
  {
    icon: <Users className="text-primary text-2xl" />,
    title: "Patient Experience Gaps",
    description: "Enhance patient satisfaction with personalized communication and seamless experiences."
  }
];

export default function KeyChallenges() {
  return (
    <section className="py-20 bg-neutral-100" id="challenges">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-800 mb-4">Key Challenges We Solve</h2>
          <p className="text-lg text-neutral-500">
            Our AI solutions address the most pressing challenges faced by dental practices operating at full capacity.
          </p>
        </motion.div>
        
        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {challenges.map((challenge, index) => (
            <motion.div 
              key={index}
              variants={fadeIn}
              className="bg-white rounded-xl shadow-lg p-8 border-t-4 border-primary hover:shadow-xl transition duration-300 transform hover:-translate-y-1"
            >
              <div className="bg-primary bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                {challenge.icon}
              </div>
              <h3 className="text-xl font-bold text-neutral-800 mb-3">{challenge.title}</h3>
              <p className="text-neutral-500">
                {challenge.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
