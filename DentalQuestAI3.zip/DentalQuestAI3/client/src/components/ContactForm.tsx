import { useState } from "react";
import { motion } from "framer-motion";
import { fadeIn, slideInUp } from "@/lib/animations";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { QuoteIcon } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  practice: z.string().min(2, "Practice name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(6, "Phone number is required"),
  chairs: z.string().min(1, "Please select number of chairs"),
});

type FormValues = z.infer<typeof formSchema>;

export default function ContactForm() {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      practice: "",
      email: "",
      phone: "",
      chairs: "",
    },
  });

  const { mutate, isPending } = useMutation({
    mutationFn: (data: FormValues) => 
      apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Demo request submitted!",
        description: "We'll contact you soon to schedule your personalized demo.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error submitting form",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    mutate(data);
  };

  return (
    <section className="py-16 bg-neutral-100" id="demo">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={slideInUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="bg-white rounded-xl shadow-xl overflow-hidden"
        >
          <div className="grid md:grid-cols-2">
            <div className="p-8 md:p-12">
              <h2 className="text-3xl font-bold text-neutral-800 mb-6">Unlock Your Practice's Full Potential</h2>
              <p className="text-lg text-neutral-500 mb-8">
                Schedule your personalized AI demo today and discover how our solutions can transform your practice operations.
              </p>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Dr. John Smith" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="practice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Practice Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Smith Dental Care" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john@smithdental.com" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="(555) 123-4567" type="tel" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="chairs"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Operatories</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select number of chairs" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1-3">1-3 Chairs</SelectItem>
                            <SelectItem value="4-6">4-6 Chairs</SelectItem>
                            <SelectItem value="7-10">7-10 Chairs</SelectItem>
                            <SelectItem value="11+">11+ Chairs</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-2">
                    <Button 
                      type="submit" 
                      className="w-full bg-primary hover:bg-primary/90 text-white"
                      disabled={isPending}
                    >
                      {isPending ? "Submitting..." : "Schedule My Personalized Demo"}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
            
            <div className="hidden md:block">
              <div className="h-full relative">
                <img 
                  src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="Modern dental practice using technology" 
                  className="object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-primary bg-opacity-30"></div>
                <motion.div 
                  variants={fadeIn}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  className="absolute bottom-8 left-8 right-8 bg-white bg-opacity-90 p-6 rounded-lg"
                >
                  <div className="flex items-start mb-4">
                    <QuoteIcon className="text-primary text-3xl mr-4 mt-1" />
                    <p className="text-neutral-800 italic">
                      "The demo was eye-opening. I had no idea how much efficiency we were missing in our practice. Implementation was smooth, and the ROI was immediate."
                    </p>
                  </div>
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-bold mr-3">
                      TP
                    </div>
                    <div>
                      <p className="font-medium text-neutral-800">Dr. Thomas Park</p>
                      <p className="text-sm text-neutral-500">Park Avenue Dental</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
