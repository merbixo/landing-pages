import { motion } from "framer-motion";
import { fadeIn, staggerContainer } from "@/lib/animations";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

const testimonials = [
  {
    quote: "Since implementing the AI scheduling system, we've eliminated gaps in our appointment book. Our production is up 22% without adding a single operatory or team member.",
    name: "Dr. Jennifer Wilson",
    practice: "Wilson Dental Associates",
    initials: "JW",
    color: "bg-primary"
  },
  {
    quote: "The patient communication platform has transformed how we interact with patients. Our front desk team now spends 75% less time on the phone, yet our patients feel more connected than ever.",
    name: "Dr. Michael Rodriguez",
    practice: "Bright Smile Dental Group",
    initials: "MR",
    color: "bg-[#4a90e2]"
  },
  {
    quote: "The revenue optimization tools identified over $300,000 in unscheduled treatment from our existing patients. We've already converted half of that into completed procedures.",
    name: "Dr. Sarah Johnson",
    practice: "Parkside Dental Care",
    initials: "SJ",
    color: "bg-[#00d084]"
  }
];

export default function Testimonials() {
  return (
    <section className="py-20 bg-white" id="testimonials">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-800 mb-4">What Dental Practices Say</h2>
          <p className="text-lg text-neutral-500">
            Hear from practice owners who have transformed their operations with our AI solutions.
          </p>
        </motion.div>
        
        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-8"
        >
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={index}
              variants={fadeIn}
              className="bg-neutral-100 rounded-xl p-8 hover:shadow-lg transition duration-300"
            >
              <div className="flex items-center mb-6">
                <div className="text-primary">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="inline-block w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
              </div>
              <p className="text-neutral-600 italic mb-6">
                "{testimonial.quote}"
              </p>
              <div className="flex items-center">
                <div className={`w-12 h-12 ${testimonial.color} rounded-full flex items-center justify-center text-white font-bold mr-4`}>
                  {testimonial.initials}
                </div>
                <div>
                  <p className="font-bold text-neutral-800">{testimonial.name}</p>
                  <p className="text-sm text-neutral-500">{testimonial.practice}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
        
        <div className="mt-16 text-center">
          <Button 
            size="lg"
            className="px-8 py-3 bg-primary text-white hover:bg-primary/90 rounded-md transition shadow-lg"
            asChild
          >
            <a href="#demo">See How It Works for Your Practice</a>
          </Button>
        </div>
      </div>
    </section>
  );
}
