import React from 'react';
import { motion } from 'framer-motion';
import { fadeIn } from '@/lib/animations';

// Types of illustrations we can render
type IllustrationType = 
  | 'ai-dentist-collaboration' 
  | 'ai-scheduler' 
  | 'ai-analysis' 
  | 'ai-patient-communication';

interface IllustrationProps {
  type: IllustrationType;
  className?: string;
}

export default function DentalAIIllustration({ type, className = '' }: IllustrationProps) {
  return (
    <motion.div 
      variants={fadeIn}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      className={`w-full h-full ${className}`}
    >
      {renderIllustration(type)}
    </motion.div>
  );
}

function renderIllustration(type: IllustrationType) {
  switch(type) {
    case 'ai-dentist-collaboration':
      return (
        <svg 
          viewBox="0 0 800 600" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.1))' }}
        >
          {/* Background elements */}
          <rect x="0" y="0" width="800" height="600" fill="#f8fafc" rx="12" />
          
          {/* Dental clinic environment */}
          <rect x="50" y="100" width="700" height="400" fill="#ffffff" rx="8" stroke="#e2e8f0" strokeWidth="2" />
          <rect x="80" y="140" width="300" height="320" fill="#f1f5f9" rx="8" />
          <rect x="420" y="140" width="300" height="320" fill="#f1f5f9" rx="8" />
          
          {/* Dental equipment */}
          <rect x="100" y="180" width="260" height="140" fill="#f8fafc" rx="5" stroke="#cbd5e1" strokeWidth="1" />
          <circle cx="230" cy="220" r="40" fill="#60a5fa" opacity="0.7" />
          <rect x="150" y="270" width="160" height="10" fill="#cbd5e1" rx="2" />
          <rect x="190" y="290" width="80" height="10" fill="#cbd5e1" rx="2" />
          
          {/* AI interface */}
          <rect x="440" y="180" width="260" height="200" fill="#f8fafc" rx="5" stroke="#cbd5e1" strokeWidth="1" />
          <circle cx="570" cy="220" r="40" fill="#a855f7" opacity="0.7" />
          <rect x="490" y="280" width="160" height="8" fill="#cbd5e1" rx="2" />
          <rect x="490" y="300" width="160" height="8" fill="#cbd5e1" rx="2" />
          <rect x="490" y="320" width="120" height="8" fill="#cbd5e1" rx="2" />
          <rect x="490" y="340" width="80" height="8" fill="#cbd5e1" rx="2" />
          
          {/* Dentist figure (simplified) */}
          <circle cx="180" cy="350" r="30" fill="#0ea5e9" />
          <rect x="165" y="380" width="30" height="50" fill="#0ea5e9" rx="5" />
          
          {/* AI representation */}
          <circle cx="520" cy="350" r="30" fill="#8b5cf6" />
          <rect x="505" y="380" width="30" height="50" fill="#8b5cf6" rx="5" />
          
          {/* Connection between AI and dentist */}
          <path d="M220 350 C 350 320, 350 380, 480 350" stroke="#94a3b8" strokeWidth="3" strokeDasharray="10,5" />
          
          {/* Digital elements */}
          <circle cx="350" cy="270" r="20" fill="#34d399" opacity="0.8" />
          <circle cx="380" cy="300" r="15" fill="#f43f5e" opacity="0.8" />
          <circle cx="320" cy="300" r="15" fill="#f97316" opacity="0.8" />
          
          {/* Title */}
          <text x="400" y="80" textAnchor="middle" fontFamily="Arial" fontSize="24" fontWeight="bold" fill="#1e293b">AI and Dentist Collaboration</text>
        </svg>
      );
      
    case 'ai-scheduler':
      return (
        <svg 
          viewBox="0 0 800 600" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.1))' }}
        >
          {/* Background */}
          <rect x="0" y="0" width="800" height="600" fill="#f8fafc" rx="12" />
          
          {/* Digital calendar */}
          <rect x="150" y="100" width="500" height="400" fill="#ffffff" rx="10" stroke="#e2e8f0" strokeWidth="2" />
          
          {/* Calendar header */}
          <rect x="150" y="100" width="500" height="60" fill="#3b82f6" rx="10 10 0 0" />
          <text x="400" y="140" textAnchor="middle" fontFamily="Arial" fontSize="22" fontWeight="bold" fill="#ffffff">Smart Scheduling Assistant</text>
          
          {/* Calendar grid */}
          <rect x="180" y="180" width="440" height="300" fill="#f8fafc" rx="5" />
          
          {/* Calendar days */}
          <rect x="180" y="180" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="253" y="180" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="326" y="180" width="74" height="50" fill="#bfdbfe" stroke="#60a5fa" strokeWidth="2" />
          <rect x="400" y="180" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="473" y="180" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="546" y="180" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          
          <rect x="180" y="230" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="253" y="230" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="326" y="230" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="400" y="230" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="473" y="230" width="73" height="50" fill="#bfdbfe" stroke="#60a5fa" strokeWidth="2" />
          <rect x="546" y="230" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          
          <rect x="180" y="280" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="253" y="280" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="326" y="280" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="400" y="280" width="73" height="50" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
          <rect x="473" y="280" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="546" y="280" width="74" height="50" fill="#bfdbfe" stroke="#60a5fa" strokeWidth="2" />
          
          <rect x="180" y="330" width="73" height="50" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
          <rect x="253" y="330" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="326" y="330" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="400" y="330" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="473" y="330" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="546" y="330" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          
          <rect x="180" y="380" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="253" y="380" width="73" height="50" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
          <rect x="326" y="380" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="400" y="380" width="73" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          <rect x="473" y="380" width="73" height="50" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
          <rect x="546" y="380" width="74" height="50" fill="#eff6ff" stroke="#cbd5e1" strokeWidth="1" />
          
          {/* AI assistant element */}
          <circle cx="640" cy="480" r="40" fill="#8b5cf6" />
          <text x="640" y="485" textAnchor="middle" fontFamily="Arial" fontSize="14" fontWeight="bold" fill="#ffffff">AI</text>
          
          {/* Smart scheduling arrows */}
          <path d="M620 450 L 580 400" stroke="#8b5cf6" strokeWidth="2" />
          <path d="M610 420 L 500 320" stroke="#8b5cf6" strokeWidth="2" />
          <path d="M630 440 L 460 300" stroke="#8b5cf6" strokeWidth="2" />
          
          {/* Animation elements */}
          <circle cx="346" cy="205" r="8" fill="#3b82f6" />
          <circle cx="510" cy="255" r="8" fill="#3b82f6" />
          <circle cx="580" cy="305" r="8" fill="#3b82f6" />
          <circle cx="210" cy="355" r="8" fill="#3b82f6" />
          <circle cx="285" cy="405" r="8" fill="#3b82f6" />
          <circle cx="510" cy="405" r="8" fill="#3b82f6" />
          
          {/* Legend */}
          <rect x="600" y="180" width="20" height="20" fill="#bfdbfe" stroke="#60a5fa" strokeWidth="2" />
          <text x="630" y="195" textAnchor="start" fontFamily="Arial" fontSize="12" fill="#475569">Booked</text>
          
          <rect x="600" y="210" width="20" height="20" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
          <text x="630" y="225" textAnchor="start" fontFamily="Arial" fontSize="12" fill="#475569">Suggested</text>
        </svg>
      );
      
    case 'ai-analysis':
      return (
        <svg 
          viewBox="0 0 800 600" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.1))' }}
        >
          {/* Background */}
          <rect x="0" y="0" width="800" height="600" fill="#f8fafc" rx="12" />
          
          {/* Main screen */}
          <rect x="100" y="100" width="600" height="400" fill="#ffffff" rx="10" stroke="#e2e8f0" strokeWidth="2" />
          
          {/* Header */}
          <rect x="100" y="100" width="600" height="60" fill="#7c3aed" rx="10 10 0 0" />
          <text x="400" y="140" textAnchor="middle" fontFamily="Arial" fontSize="22" fontWeight="bold" fill="#ffffff">AI Dental Analytics Dashboard</text>
          
          {/* X-ray/dental scan image */}
          <rect x="130" y="180" width="250" height="200" fill="#f1f5f9" rx="8" />
          <circle cx="180" cy="240" r="30" fill="#a78bfa" opacity="0.7" />
          <circle cx="230" cy="210" r="20" fill="#c4b5fd" opacity="0.5" />
          <circle cx="300" cy="290" r="40" fill="#8b5cf6" opacity="0.6" />
          <rect x="170" y="320" width="170" height="10" fill="#d1d5db" rx="2" />
          <rect x="200" y="340" width="110" height="10" fill="#d1d5db" rx="2" />
          
          {/* AI analysis area */}
          <rect x="420" y="180" width="250" height="200" fill="#f1f5f9" rx="8" />
          
          {/* Charts and data visualization */}
          <rect x="440" y="200" width="210" height="60" fill="#ede9fe" rx="5" />
          <path d="M450 240 L 480 220 L 510 230 L 540 210 L 570 225 L 600 200 L 630 230" 
                fill="none" stroke="#7c3aed" strokeWidth="3" />
                
          <rect x="440" y="280" width="100" height="80" fill="#f3e8ff" rx="5" />
          <circle cx="490" cy="320" r="30" fill="#ffffff" />
          <path d="M490 320 L 490 290 A 30 30 0 0 1 517 335 Z" fill="#7c3aed" />
          
          <rect x="550" y="280" width="100" height="80" fill="#fae8ff" rx="5" />
          <rect x="570" y="300" width="15" height="40" fill="#c026d3" rx="2" />
          <rect x="590" y="310" width="15" height="30" fill="#d946ef" rx="2" />
          <rect x="610" y="290" width="15" height="50" fill="#e879f9" rx="2" />
          
          {/* Connection lines between image and analysis */}
          <path d="M300 240 C 350 240, 350 240, 420 240" stroke="#a855f7" strokeWidth="2" strokeDasharray="5,5" />
          <path d="M280 300 C 350 300, 350 300, 440 320" stroke="#a855f7" strokeWidth="2" strokeDasharray="5,5" />
          
          {/* AI markers */}
          <circle cx="180" cy="240" r="8" fill="#f43f5e" stroke="#ffffff" strokeWidth="2" />
          <circle cx="300" cy="290" r="8" fill="#f43f5e" stroke="#ffffff" strokeWidth="2" />
          <circle cx="250" cy="260" r="8" fill="#f43f5e" stroke="#ffffff" strokeWidth="2" />
          
          {/* Legend */}
          <rect x="130" y="400" width="15" height="15" fill="#f43f5e" rx="7.5" />
          <text x="155" y="412" textAnchor="start" fontFamily="Arial" fontSize="14" fill="#475569">AI Detected Areas</text>
          
          <rect x="280" y="400" width="15" height="15" fill="#8b5cf6" rx="7.5" />
          <text x="305" y="412" textAnchor="start" fontFamily="Arial" fontSize="14" fill="#475569">Data Analysis</text>
          
          {/* Title */}
          <text x="400" y="80" textAnchor="middle" fontFamily="Arial" fontSize="18" fontWeight="bold" fill="#1e293b">Advanced Dental Analysis with AI</text>
        </svg>
      );
      
    case 'ai-patient-communication':
      return (
        <svg 
          viewBox="0 0 800 600" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.1))' }}
        >
          {/* Background */}
          <rect x="0" y="0" width="800" height="600" fill="#f8fafc" rx="12" />
          
          {/* Main panels */}
          <rect x="50" y="100" width="700" height="400" fill="#ffffff" rx="10" stroke="#e2e8f0" strokeWidth="2" />
          
          {/* Title */}
          <text x="400" y="80" textAnchor="middle" fontFamily="Arial" fontSize="22" fontWeight="bold" fill="#1e293b">AI-Powered Patient Communication</text>
          
          {/* Patient database panel */}
          <rect x="80" y="130" width="300" height="340" fill="#f1f5f9" rx="8" />
          <text x="230" y="160" textAnchor="middle" fontFamily="Arial" fontSize="18" fontWeight="bold" fill="#334155">Patient Database</text>
          
          {/* Patient records */}
          <rect x="100" y="180" width="260" height="50" fill="#ffffff" rx="6" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx="125" cy="205" r="15" fill="#0ea5e9" opacity="0.7" />
          <rect x="150" y="195" width="120" height="8" fill="#d1d5db" rx="2" />
          <rect x="150" y="210" width="80" height="8" fill="#d1d5db" rx="2" />
          <rect x="280" y="195" width="60" height="20" fill="#bfdbfe" rx="4" />
          <text x="310" y="210" textAnchor="middle" fontFamily="Arial" fontSize="10" fill="#1e40af">Due</text>
          
          <rect x="100" y="240" width="260" height="50" fill="#ffffff" rx="6" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx="125" cy="265" r="15" fill="#f97316" opacity="0.7" />
          <rect x="150" y="255" width="120" height="8" fill="#d1d5db" rx="2" />
          <rect x="150" y="270" width="80" height="8" fill="#d1d5db" rx="2" />
          <rect x="280" y="255" width="60" height="20" fill="#fed7aa" rx="4" />
          <text x="310" y="270" textAnchor="middle" fontFamily="Arial" fontSize="10" fill="#7c2d12">Overdue</text>
          
          <rect x="100" y="300" width="260" height="50" fill="#ffffff" rx="6" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx="125" cy="325" r="15" fill="#10b981" opacity="0.7" />
          <rect x="150" y="315" width="120" height="8" fill="#d1d5db" rx="2" />
          <rect x="150" y="330" width="80" height="8" fill="#d1d5db" rx="2" />
          <rect x="280" y="315" width="60" height="20" fill="#a7f3d0" rx="4" />
          <text x="310" y="330" textAnchor="middle" fontFamily="Arial" fontSize="10" fill="#065f46">Current</text>
          
          <rect x="100" y="360" width="260" height="50" fill="#ffffff" rx="6" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx="125" cy="385" r="15" fill="#6366f1" opacity="0.7" />
          <rect x="150" y="375" width="120" height="8" fill="#d1d5db" rx="2" />
          <rect x="150" y="390" width="80" height="8" fill="#d1d5db" rx="2" />
          <rect x="280" y="375" width="60" height="20" fill="#c7d2fe" rx="4" />
          <text x="310" y="390" textAnchor="middle" fontFamily="Arial" fontSize="10" fill="#3730a3">Follow-up</text>
          
          {/* AI Communication panel */}
          <rect x="420" y="130" width="300" height="340" fill="#f1f5f9" rx="8" />
          <text x="570" y="160" textAnchor="middle" fontFamily="Arial" fontSize="18" fontWeight="bold" fill="#334155">AI Communication</text>
          
          {/* AI bubble */}
          <circle cx="480" cy="200" r="30" fill="#8b5cf6" />
          <text x="480" y="205" textAnchor="middle" fontFamily="Arial" fontSize="14" fontWeight="bold" fill="#ffffff">AI</text>
          
          {/* Message bubbles */}
          <rect x="450" y="250" width="240" height="40" fill="#ddd6fe" rx="8" />
          <text x="480" y="275" textAnchor="start" fontFamily="Arial" fontSize="12" fill="#5b21b6">Appointment reminder for treatment plan</text>
          
          <rect x="450" y="300" width="240" height="40" fill="#ddd6fe" rx="8" />
          <text x="480" y="325" textAnchor="start" fontFamily="Arial" fontSize="12" fill="#5b21b6">Follow-up about recent procedure</text>
          
          <rect x="450" y="350" width="240" height="40" fill="#ddd6fe" rx="8" />
          <text x="480" y="375" textAnchor="start" fontFamily="Arial" fontSize="12" fill="#5b21b6">Re-engagement for inactive patients</text>
          
          {/* Communication channels */}
          <circle cx="680" cy="250" r="10" fill="#0ea5e9" />
          <text x="680" y="254" textAnchor="middle" fontFamily="Arial" fontSize="10" fontWeight="bold" fill="#ffffff">E</text>
          
          <circle cx="680" cy="300" r="10" fill="#10b981" />
          <text x="680" y="304" textAnchor="middle" fontFamily="Arial" fontSize="10" fontWeight="bold" fill="#ffffff">S</text>
          
          <circle cx="680" cy="350" r="10" fill="#f59e0b" />
          <text x="680" y="354" textAnchor="middle" fontFamily="Arial" fontSize="10" fontWeight="bold" fill="#ffffff">C</text>
          
          {/* Connection arrows between database and communication */}
          <path d="M380 205 Q 400 205, 420 200" stroke="#8b5cf6" strokeWidth="2" fill="none" />
          <path d="M380 265 Q 400 265, 420 300" stroke="#8b5cf6" strokeWidth="2" fill="none" />
          <path d="M380 325 Q 400 325, 420 350" stroke="#8b5cf6" strokeWidth="2" fill="none" />
          
          {/* Legend */}
          <circle cx="440" cy="430" r="8" fill="#0ea5e9" />
          <text x="455" y="433" textAnchor="start" fontFamily="Arial" fontSize="10" fill="#334155">Email</text>
          
          <circle cx="500" cy="430" r="8" fill="#10b981" />
          <text x="515" y="433" textAnchor="start" fontFamily="Arial" fontSize="10" fill="#334155">SMS</text>
          
          <circle cx="560" cy="430" r="8" fill="#f59e0b" />
          <text x="575" y="433" textAnchor="start" fontFamily="Arial" fontSize="10" fill="#334155">Call</text>
        </svg>
      );
      
    default:
      return null;
  }
}