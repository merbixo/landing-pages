import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className={`fixed w-full bg-white z-50 transition-shadow duration-300 ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <a href="#" className="flex items-center">
              <div className="text-primary font-bold text-2xl mr-2">
                <span className="text-primary">Dental</span>
                <span className="text-[#00d084]">AI</span>
              </div>
            </a>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-neutral-500 hover:text-primary font-medium transition">Features</a>
            <a href="#benefits" className="text-neutral-500 hover:text-primary font-medium transition">Benefits</a>
            <a href="#testimonials" className="text-neutral-500 hover:text-primary font-medium transition">Testimonials</a>
            <a href="#contact" className="text-neutral-500 hover:text-primary font-medium transition">Contact</a>
            <a href="#demo">
              <Button className="bg-primary hover:bg-primary/90 text-white transition shadow-sm">
                Request Demo
              </Button>
            </a>
          </nav>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleMenu}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile navigation */}
        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <div className="flex flex-col space-y-3">
              <a 
                href="#features" 
                className="text-neutral-500 hover:text-primary font-medium px-4 py-2 rounded hover:bg-neutral-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Features
              </a>
              <a 
                href="#benefits" 
                className="text-neutral-500 hover:text-primary font-medium px-4 py-2 rounded hover:bg-neutral-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Benefits
              </a>
              <a 
                href="#testimonials" 
                className="text-neutral-500 hover:text-primary font-medium px-4 py-2 rounded hover:bg-neutral-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Testimonials
              </a>
              <a 
                href="#contact" 
                className="text-neutral-500 hover:text-primary font-medium px-4 py-2 rounded hover:bg-neutral-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </a>
              <a 
                href="#demo"
                onClick={() => setIsMenuOpen(false)}
                className="mx-4"
              >
                <Button className="w-full bg-primary hover:bg-primary/90 text-white transition shadow-sm">
                  Request Demo
                </Button>
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
