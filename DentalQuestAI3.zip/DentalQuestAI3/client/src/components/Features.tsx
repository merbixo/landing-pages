import React from "react";
import { motion } from "framer-motion";
import { fadeIn, slideInLeft, slideInRight } from "@/lib/animations";
import { CheckCircle } from "lucide-react";

const features = [
  {
    title: "Intelligent Scheduling System",
    description: "Our AI-driven scheduling system automatically identifies and fills appointment gaps, maximizing chair utilization and preventing revenue loss from last-minute cancellations.",
    benefits: [
      "Instantly fills canceled appointments from waitlist",
      "Optimizes provider schedules based on procedure types",
      "Reduces no-shows with smart reminder system"
    ],
    image: "https://images.unsplash.com/photo-1606811971618-4486d14f3f99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Automated Patient Communications",
    description: "Free your staff from repetitive tasks with AI-powered communication tools that deliver personalized messages to patients at the right time through their preferred channels.",
    benefits: [
      "Personalized messages based on patient history",
      "Multi-channel delivery (SMS, email, voice)",
      "Smart follow-ups for treatment plan acceptance"
    ],
    image: "https://images.unsplash.com/photo-1516981879613-9f5da904015f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Revenue Optimization Tools",
    description: "Reactivate overdue treatments using insightful analytics, maximizing revenue from your current patient base without adding new patients.",
    benefits: [
      "Identifies unscheduled treatment opportunities",
      "Prioritizes high-value procedures",
      "Tracks and optimizes case acceptance rates"
    ],
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
  }
];

export default function Features() {
  return (
    <section className="py-20 bg-white" id="features">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-800 mb-4">AI-Powered Features</h2>
          <p className="text-lg text-neutral-500">
            Advanced technology designed specifically for busy dental practices to optimize every aspect of your operations.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-x-12 gap-y-20 items-center">
          {features.flatMap((feature, index) => [
            <motion.div 
              key={`img-${index}`}
              variants={index % 2 === 0 ? slideInLeft : slideInRight}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className={`order-1 md:order-${index % 2 === 0 ? "1" : "2"}`}
            >
              <div className="bg-neutral-100 p-1 rounded-2xl">
                <img 
                  src={feature.image} 
                  alt={feature.title} 
                  className="rounded-xl w-full h-[350px] object-cover"
                />
              </div>
            </motion.div>,
            
            <motion.div 
              key={`content-${index}`}
              variants={index % 2 === 0 ? slideInRight : slideInLeft}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className={`order-2 md:order-${index % 2 === 0 ? "2" : "1"}`}
            >
              <h3 className="text-2xl font-bold text-neutral-800 mb-4">{feature.title}</h3>
              <p className="text-lg text-neutral-500 mb-6">
                {feature.description}
              </p>
              <ul className="space-y-3">
                {feature.benefits.map((benefit, benefitIndex) => (
                  <li className="flex items-start" key={benefitIndex}>
                    <CheckCircle className="text-[#00d084] h-5 w-5 mt-1 mr-3" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ])}
        </div>
      </div>
    </section>
  );
}
