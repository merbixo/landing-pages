import React, { useRef, useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

const GREETING_TEXT = `
Hello! I'm Sophie, your virtual dental assistant.
I'd be delighted to show you how our AI technology can transform your dental practice.
From filling scheduling gaps to automating patient communications,
our intelligent solutions can boost your revenue and enhance patient satisfaction.
How may I assist you with your practice today?
`;

// Helper function to detect female voices
const isFemaleVoice = (voice: SpeechSynthesisVoice): boolean => {
  const name = voice.name.toLowerCase();
  return (
    name.includes('female') || 
    name.includes('woman') || 
    name.includes('girl') ||
    name.includes('samantha') ||
    name.includes('victoria') ||
    name.includes('karen') ||
    name.includes('moira') ||
    name.includes('tessa') ||
    name.includes('zira') ||
    name.includes('lisa') ||
    name.includes('laura') ||
    name.includes('nora') ||
    name.includes('clara')
  );
};

export default function AudioGreeting() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  
  // Initialize and select a female voice when component mounts
  useEffect(() => {
    // Function to find the best female voice
    const findBestFemaleVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      
      // First try to find female voices
      const femaleVoices = voices.filter(isFemaleVoice);
      
      if (femaleVoices.length > 0) {
        // Prefer high-quality voices (localService is true for higher quality voices)
        const highQualityFemaleVoice = femaleVoices.find(voice => voice.localService);
        setSelectedVoice(highQualityFemaleVoice || femaleVoices[0]);
        console.log('Selected female voice:', highQualityFemaleVoice?.name || femaleVoices[0]?.name);
      } else if (voices.length > 0) {
        // If no female voice found, use the default
        setSelectedVoice(voices[0]);
        console.log('No female voice found, using default:', voices[0]?.name);
      }
    };
    
    // Load voices if available
    if (window.speechSynthesis) {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        findBestFemaleVoice();
      } else {
        // Set up event listener to get voices when they're loaded
        window.speechSynthesis.onvoiceschanged = findBestFemaleVoice;
      }
    }
    
    // Cleanup
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);
  
  const handlePlay = () => {
    // In a production environment, this would play an actual audio file
    // For this demo, we'll use the browser's speech synthesis API
    if (!isPlaying) {
      const utterance = new SpeechSynthesisUtterance(GREETING_TEXT);
      utterance.rate = 0.9; // Slightly slower rate for clarity
      utterance.pitch = 1.1; // Slightly higher pitch for a friendly tone
      utterance.volume = 1;
      
      // Use the preselected voice if available
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        console.log('Using voice:', selectedVoice.name, '(Female voice:', isFemaleVoice(selectedVoice), ')');
      } else {
        // Fallback - try to select a voice on the spot
        const voices = window.speechSynthesis.getVoices();
        const femaleVoices = voices.filter(isFemaleVoice);
        
        if (femaleVoices.length > 0) {
          utterance.voice = femaleVoices[0];
          console.log('Fallback to female voice:', femaleVoices[0].name);
        } else {
          console.log('No female voice available, using browser default');
        }
      }
      
      utterance.onend = () => setIsPlaying(false);
      window.speechSynthesis.speak(utterance);
      setIsPlaying(true);
    } else {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  return (
    <button
      onClick={handlePlay}
      className="bg-white/20 hover:bg-white/30 p-2 rounded-full transition-colors"
      aria-label={isPlaying ? "Stop audio greeting" : "Play audio greeting"}
      title={isPlaying ? "Stop audio greeting" : "Play audio greeting"}
    >
      {isPlaying ? <VolumeX size={18} /> : <Volume2 size={18} />}
    </button>
  );
}