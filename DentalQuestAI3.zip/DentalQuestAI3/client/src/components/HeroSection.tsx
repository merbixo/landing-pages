import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { fadeIn, slideInLeft, slideInRight } from "@/lib/animations";

export default function HeroSection() {
  return (
    <section 
      className="pt-32 pb-20 text-white" 
      id="hero"
      style={{
        background: "linear-gradient(90deg, rgba(0,86,179,0.95) 0%, rgba(0,208,132,0.85) 100%)"
      }}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            variants={slideInLeft}
            initial="hidden"
            animate="visible"
          >
            <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
              Elevate Your Fully Booked Dental Practice with Smart AI Solutions
            </h1>
            <p className="text-lg md:text-xl mb-8 opacity-90">
              Optimize efficiency, reduce operational costs, and maximize revenue opportunities for your dental practice operating at full capacity.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                size="lg"
                variant="secondary" 
                className="bg-white text-primary hover:bg-neutral-100 transition shadow-lg"
                asChild
              >
                <a href="#demo">Schedule Your AI Demo</a>
              </Button>
              <Button 
                size="lg"
                variant="outline" 
                className="border-2 border-white text-white bg-transparent hover:bg-white hover:bg-opacity-10 transition"
                asChild
              >
                <a href="#features">Explore Features</a>
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            variants={slideInRight}
            initial="hidden"
            animate="visible"
            className="hidden md:block relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
              alt="Modern dental practice with technology" 
              className="rounded-xl shadow-2xl object-cover h-[500px] w-full"
            />
            <motion.div 
              variants={fadeIn} 
              initial="hidden"
              animate="visible"
              transition={{ delay: 0.6 }}
              className="absolute -bottom-6 -right-6 bg-[#00d084] p-4 rounded-lg shadow-lg"
            >
              <p className="font-bold text-xl">98%</p>
              <p className="text-sm">Chair Utilization</p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
