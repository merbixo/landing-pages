import { motion } from "framer-motion";
import { fadeIn, staggerContainer } from "@/lib/animations";

const benefits = [
  {
    stat: "+30%",
    title: "Increased Productivity",
    description: "Streamline workflows and eliminate manual tasks, allowing your team to focus on patient care."
  },
  {
    stat: "-25%",
    title: "Reduced No-Shows",
    description: "Smart reminder system and waitlist management dramatically decreases missed appointments."
  },
  {
    stat: "+15%",
    title: "Revenue Growth",
    description: "Identify and capitalize on untapped treatment opportunities within your existing patient base."
  },
  {
    stat: "98%",
    title: "Chair Utilization",
    description: "Maximize your practice's most valuable asset by keeping chairs filled throughout the day."
  },
  {
    stat: "+40%",
    title: "Staff Satisfaction",
    description: "Reduce administrative burden, allowing team members to focus on meaningful patient interactions."
  },
  {
    stat: "+45%",
    title: "Patient Satisfaction",
    description: "Deliver exceptional, personalized service that keeps patients loyal to your practice."
  }
];

export default function Benefits() {
  return (
    <section className="py-20 bg-primary text-white" id="benefits">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Benefits for Your Practice</h2>
          <p className="text-lg opacity-90">
            Our AI solutions deliver measurable improvements to your dental practice operations and bottom line.
          </p>
        </motion.div>
        
        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {benefits.map((benefit, index) => (
            <motion.div 
              key={index}
              variants={fadeIn}
              className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-8 hover:bg-opacity-20 transition duration-300"
            >
              <div className="text-[#00d084] text-5xl mb-6 font-bold">{benefit.stat}</div>
              <h3 className="text-xl font-bold mb-3">{benefit.title}</h3>
              <p className="opacity-90">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
