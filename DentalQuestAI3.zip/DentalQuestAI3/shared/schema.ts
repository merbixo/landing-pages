import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Schema for contact/demo request form
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  practice: text("practice").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  chairs: text("chairs").notNull(),
  created_at: text("created_at").notNull().default(new Date().toISOString()),
});

export const contactSchema = z.object({
  name: z.string().min(2, "Name is required"),
  practice: z.string().min(2, "Practice name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(6, "Phone number is required"),
  chairs: z.string().min(1, "Please select number of chairs"),
});

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof contactSchema>;
